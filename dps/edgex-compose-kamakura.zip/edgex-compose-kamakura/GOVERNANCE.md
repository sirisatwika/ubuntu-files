# Governance

Project governance as well as policies, procedures and instructions for contributing to EdgeX Foundry can be found on our Wiki site at the following locations:

- [EdgeX Technical Steering Committee](https://wiki.edgexfoundry.org/pages/viewpage.action?pageId=329436)
- [Contributor's Guide](https://wiki.edgexfoundry.org/display/FA/Contributor%27s+Guide)
- [Contributor's Process](https://wiki.edgexfoundry.org/display/FA/Contributor%27s+Process)
- [Technical Work](https://wiki.edgexfoundry.org/display/FA/Technical+Work+in+the+EdgeX+Foundry+Project)
- [Contributors, Committers & Maintainers](https://wiki.edgexfoundry.org/pages/viewpage.action?pageId=21823860)