# Repository Owners

This repository is managed by the EdgeX Core Working Group.  As such, the **Core Working Group** chairman is considered the "owner" of the repository and approves all committers of the repository.

See the [project Wiki TSC page](https://wiki.edgexfoundry.org/pages/viewpage.action?pageId=329436#TechnicalSteeringCommittee(TSC)-WorkingGroups) for information on the current EdgeX TSC and who occupies the role of Core Working Group chair.

For a complete list of current committers see: https://github.com/orgs/edgexfoundry/teams/edgex-compose-committers/members.

